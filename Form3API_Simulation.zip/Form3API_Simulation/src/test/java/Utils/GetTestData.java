package Utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class GetTestData {

    static Properties pro = new Properties();

    public GetTestData(){
        File src = new File("C:/Users/sandeep.ahalawat/Downloads/Automation Practice/Form3API_Simulation/src/test/java/TestData/TestData.properties");
        try {
            FileInputStream fis = new FileInputStream(src);
            pro = new Properties();
            pro.load(fis);
        } catch (Exception e) {
            System.out.println("Exception is " + e.getMessage());
        }
    }

    public static String getBaseURI()
    {
        String url=pro.getProperty("baseURI");
        return url;
    }

    public static String getAuthorization()
    {
        String auth=pro.getProperty("authorization");
        return auth;
    }
}
