package StepDefinition;

import Utils.DateUtils;
import Utils.GetTestData;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.Getter;
import lombok.val;
import org.junit.Assert;
import org.junit.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GetSubscriptions {

    private static Response response;

    @Given("Subscriptions are available in the FORM3")
    public void verifyBucketExists() {
        System.out.println("Subscriptions are available in FORM3");
    }

    @When("user request the subscriptions details using GET method")
    public void requestGETmethod() {

        RestAssured.baseURI = GetTestData.getBaseURI();
        System.out.println("1");
        RequestSpecification httpsRequest = RestAssured.given().headers("Authorization", GetTestData.getAuthorization()).headers("Date", DateUtils.getCurrentDate());
        System.out.println("2");
        response = httpsRequest.request(Method.GET);
        System.out.println("3");
    }

    @Then("verify the status code is <status code>")
    public void verifyResponse() {

        System.out.println("4");
        Assert.assertEquals(response.getStatusCode(), 200);

    }

}

