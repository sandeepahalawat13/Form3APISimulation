package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "C:/Users/sandeep.ahalawat/Downloads/Automation Practice/Form3API_Simulation/Features",
        glue = "StepDefinition",
        dryRun = true,
        monochrome = true
)
public class TestRunner {}
